/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.uts_no3_c_3102;

/**
 *
 * @author badnoby
 */
public class StudentStaff_3102 extends Mahasiswa_3102 {
    int jamKerja_3102;
    String unitKerja_3102;
    
    public double totalPendapatan_3102(){
        return (jamKerja_3102 * 30000);
    }
    public void tampilDataStudentStaff_3102(){
        super.tampilDataMhs_3102();
        System.out.println(" Unit Kerja : " + unitKerja_3102);
        System.out.println(" Jam Kerja : " +jamKerja_3102);
        System.out.println(" Total Pendapatan Student Staff : " +totalPendapatan_3102());
    }
}
