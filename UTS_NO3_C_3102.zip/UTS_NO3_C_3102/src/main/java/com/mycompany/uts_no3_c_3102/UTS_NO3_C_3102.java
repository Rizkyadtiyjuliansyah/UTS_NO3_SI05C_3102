/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.uts_no3_c_3102;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 *
 * @author badnoby
 */
public class UTS_NO3_C_3102 {

    public static void main(String[] args) {
        //Membuat object menggunakan array
        AsistenPraktikum_3102[] AsPrak_3102 = new AsistenPraktikum_3102[1];
        StudentStaff_3102[] StuStaff_3102 = new StudentStaff_3102[1];
        
        AsPrak_3102[0] = new AsistenPraktikum_3102();
        StuStaff_3102[0] = new StudentStaff_3102();

        //program input menggunakan buffered reader
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
         
        try {
            //mengisi data ke array pada data nelayan
            for(int i = 0; i < 1; i++){
                System.out.print("NIM              : ");
                AsPrak_3102[i].nim_3102 = br.readLine();
                System.out.print("Nama             : ");
                AsPrak_3102[i].nama_3102 = br.readLine();
                System.out.print("Jurusan          : ");
                AsPrak_3102[i].jurusan_3102 =br.readLine();
                System.out.print("IPK              : ");
                AsPrak_3102[i].ipk_3102 =Integer.parseInt(br.readLine());
                System.out.print("Mata Kuliah      : ");
                AsPrak_3102[i].mkAsisten_3102 = br.readLine();
                System.out.print("Jumlah Pertemuan : ");
                AsPrak_3102[i].jmlPertemuan_3102 = Integer.parseInt(br.readLine());
                System.out.println();
            }
            
            //Menampilkan semua isi array pada data nelayan
            System.out.println("DATA ASISTEN PRAKTIKUM");
            for(AsistenPraktikum_3102 AP : AsPrak_3102){
                AP.tampilDataAsistenPraktikum_3102();
                System.out.println("");
            }

            //mengisi data ke array pada data dokter
            for(int i = 0; i < 1; i++){
                System.out.print("NIM         : ");
                StuStaff_3102[i].nim_3102 = br.readLine();
                System.out.print("Nama        : ");
                StuStaff_3102[i].nama_3102 = br.readLine();
                System.out.print("Jurusan     : ");
                StuStaff_3102[i].jurusan_3102 =br.readLine();
                System.out.print("IPK         : ");
                StuStaff_3102[i].ipk_3102 =Integer.parseInt(br.readLine());
                System.out.print(" Unit Kerja : ");
                StuStaff_3102[i].unitKerja_3102 = br.readLine();
                System.out.print("Jam Kerja   : ");
                StuStaff_3102[i].jamKerja_3102 = Integer.parseInt(br.readLine());
                System.out.println();
            }
            
            //Menampilkan semua isi array pada data dokter
            System.out.println("DATA STUDENT STAFF");
            for(StudentStaff_3102 SS : StuStaff_3102){
                SS.tampilDataStudentStaff_3102();
                System.out.println("");
            }
        } 
        catch (Exception ex){ // menangkap kesalahan
            System.out.println(ex);
        }
    }
}
