/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.uts_no3_c_3102;

/**
 *
 * @author badnoby
 */
public interface Pendapatan_3102 {
    public double totalPendapatan_3102 ();
}
