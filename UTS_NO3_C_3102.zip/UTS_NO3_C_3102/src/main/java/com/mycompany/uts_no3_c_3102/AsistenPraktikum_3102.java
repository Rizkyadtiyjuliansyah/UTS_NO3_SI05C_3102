/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.uts_no3_c_3102;

/**
 *
 * @author badnoby
 */
public class AsistenPraktikum_3102 extends Mahasiswa_3102 {
    String mkAsisten_3102;
    int jmlPertemuan_3102;
    
    public double totalPendapatan_3102(){
        return(jmlPertemuan_3102 * 50000);
    }
    public void tampilDataAsistenPraktikum_3102() {
        super.tampilDataMhs_3102();
        System.out.println(" Mata Kuliah    : " + mkAsisten_3102);
        System.out.println(" Jumlah Pertemuan   : " + jmlPertemuan_3102);
        System.out.println(" Total Pendapatan : " + totalPendapatan_3102());
        
        
    }
}
