/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.uts_no3_c_3102;

/**
 *
 * @author badnoby
 */
import java.io.BufferedReader;
public class Mahasiswa_3102 {
    String nim_3102, nama_3102, jurusan_3102;
    int ipk_3102;
    
    public void tampilDataMhs_3102() {
        System.out.println(" NIM    : " + nim_3102);
        System.out.println("Nama    " + nama_3102);
        System.out.println("Jurusan    : " + jurusan_3102);
        System.out.println("IPK : " + ipk_3102);
    }
}
